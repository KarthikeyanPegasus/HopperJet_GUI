# HOPPERJET - Network Reconnaissance Framework Tool
A network based reconnaissance tool with a complete framework established which enables the user to gather data in any aspect related to a particular network.
The tool has less learning curve and is user friendly compared the other well-known market tools. This tool can be used by anyone irrespective of their background or expertise.

## Development part
The tool is coded in Python script and is a compilation of various different libraries and files.
The GUI part is built using ******** .

## HOW TO ACCESS
```WORK IN PROGRESS ```

## DOWNLOAD
- For Linux users, Clone the repository using ``git clone`` command and open the files using local browser. 
- For Windows users, Download all files in the same order, extract them.
 
 ## DISCLAIMER
LICENSE belongs to Sakthivel Ramasamy, Karthikeyan P, Yayady S
